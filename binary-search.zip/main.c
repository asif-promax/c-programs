/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int arr[]={33,44,55,66,77,88};
    int left=0;
    int right= (sizeof(arr)/sizeof(arr[0]))-1;
    int n,middle;
    printf("Enter searching element:");
    scanf("%d",&n);
    while(left<=right){
        middle=(left+right)/2;
        if(arr[middle]==n){
            printf("%d is found",n);
            break;
        }else if(arr[middle]>n){
            right=middle-1;
        }else{
            left=middle+1;
        }
    }
   // if(left>right){
        printf("Element(%d) is not found",n);
   // }
    
    return 0;
}