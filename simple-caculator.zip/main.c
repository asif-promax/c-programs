/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num1,num2,choice;
    printf("Enter 2 numbers:");
    scanf("%d%d",&num1,&num2);
    printf("\n 1:add\n 2:sub\n 3:multiple\n 4:divitin\n");
    printf("enter a choice : ");
    scanf("%d",&choice);
    switch(choice){
        case 1:printf("Result : %d",num1+num2);
        break;
        case 2:printf("Result : %d",num1-num2);
        break;
        case 3:printf("Result : %d",num1*num2);
        break;
        case 4:printf("Result : %d",num1/num2);
        break;
        case 5:
        return 0;
        default:printf("you enterd wrong choice");
    }
    return 0;
}
