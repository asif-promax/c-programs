/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int fun(int fnum,int lnum){
    int sum=0;
    for(int i=fnum;i<=lnum;i++){
         printf("%d\n",i);
         sum+=i;
         
     }
     return sum;
}

int main()
{
    int fnum,lnum,sum;
    printf("enter starting and end numbers:");
     scanf("%d%d",&fnum,&lnum);
     sum=fun(fnum,lnum);
     printf("sum = %d",sum);

    return 0;
}