#include <stdio.h>

int main()
{
    int i,ele,search;
    printf("Enter the number of element:");
    scanf("%d",&ele);
    int arr[ele];
    printf("Create a array:");
    for(i=0;i<ele;i++){
    scanf("%d",&arr[i]);
    }
    printf("Enter search element:");
    scanf("%d",&search);
    for(i=0;i<ele;i++){
        if(arr[i]==search){
            printf("%d is found",search);
            return 0;
        }
    }
    if(i==ele){
        printf("%d is not found",search);
    }

    return 0;
}