/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n1,n2,n3;
    printf("Enter 3 numbers:");
    scanf("%d%d%d",&n1,&n2,&n3);
    if(n1==n2 && n2==n3){
        printf("all are equal :%d",n1);
    }
    else if(n1>n2 && n2>n3){
        printf("%d is greater",n1);
    }else if(n2>n1 && n2>n3){
        printf("%d is greater",n2);
    }else{
        printf("%d is greater",n3);
    }
    return 0;
}