#include<stdio.h>

int main()
{
    int i;
    for(i='A';i<='Z';i++){
        printf("%c ",i);
    }
    return 0;
}