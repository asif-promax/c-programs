/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    //int arr[]={86,56,76,45,3,12,0};
    //int length=sizeof(arr)/sizeof(arr[0]);
    int i,j,temp,length;
    printf("enter no of element:");
    scanf("%d",&length);
    int arr[length];
    
   // printf("%d",length);
   printf("Enter elements :\n");
   //scaning the unsored array
   for(i=0;i<length;i++){
       scanf("%d",&arr[i]);
   }
   //selectin sort
   for(i=0;i<length;i++){
       for(j=i+1;j<length;j++){
           if(arr[i]>arr[j]){
               temp=arr[i];
               arr[i]=arr[j];
               arr[j]=temp;
           }
       }
    
   }
   printf("\n");
   for(i=0;i<length;i++){
       printf("%d ",arr[i]);
   }

    return 0;
}
