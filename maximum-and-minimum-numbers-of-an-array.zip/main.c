/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int i,j,len,temp;
    printf("enter number of element: ");
    scanf("%d",&len);
    int array[len];
    printf("elements f array:");
    for(i=0;i<len;i++){
        scanf("%d",&array[i]);
    }
    for(i=0;i<len;i++){
        for(j=i+1;j<len;j++){
            if(array[i]>array[j]){
                temp=array[i];
                array[i]=array[j];
                array[j]=temp;
            }
        }
    }
    printf("maximum number of array=%d\n",array[len-1]);
    printf("minimum number of array=%d",array[0]);

    return 0;
}