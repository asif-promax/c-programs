#include<stdio.h>

int main()
{
    float r;
    const float pi=3.14;
    printf("Enter radios of circle in meter :");
    scanf("%f",&r);
    printf("area of circle : %.2f meters\n",pi*(r*r));
    printf("perimeter of circle :%.2f meters", 2*pi*r);
    return 0;
}