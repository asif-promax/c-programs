/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num,i,to,result;
    printf("enter number to multiply:");
    scanf("%d",&num);
    printf("to:");
    scanf("%d",&to);
    
    for(i=1;i<=to;i++){
        result=num*i;
        printf("%d*%d=%d\n",num,i,result);
    }

    return 0;
}
