/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int mul(int a,int b,int c){
    return a*b*c;
}

int main()
{
    int a,b,c,multiple;
    printf("Enter 3 numbers :");
    scanf("%d%d%d",&a,&b,&c);
    multiple = mul(a,b,c);
    printf("%d",multiple);

    return 0;
}
