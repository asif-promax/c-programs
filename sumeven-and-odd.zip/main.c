/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int size,i,sum=0,s=0;
    printf("enter size :");
    scanf("%d",&size);
    for(i=1;i<=size;i++){
        if(i%2==0){
            printf("%d is even number \n",i);
            sum+=i;
        }else{
            printf("%d is odd number\n",i);
            s+=i;
        }
        
    }
    printf("sum of even= %d\n",sum);
    printf("sum of odd= %d",s);

    return 0;
}