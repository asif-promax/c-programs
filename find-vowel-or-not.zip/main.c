/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char charectur;
    printf("Enter a charectur :");
    scanf("%c",&charectur);
    if(charectur == 'a' || charectur =='A' || charectur =='e' || charectur =='E' || charectur =='i'||charectur =='I'||charectur =='o'||charectur =='O'||charectur =='u'||charectur =='U'){
        printf("%c is vavul",charectur);
    }else{
        printf("%c is cansonent",charectur);
    }

    return 0;
}
