/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int size,i;
    printf("Enter size of an array:");
    scanf("%d",&size);
    int array[size];
    printf("enter elements:");
    for(i=0;i<size;i++){
        scanf("%d",&array[i]);
    }
    printf("Even numbers:");
    for(i=0;i<size;i++){
        if(array[i]%2==0){
            printf("%d ",array[i]);
        }
    }

    return 0;
}
