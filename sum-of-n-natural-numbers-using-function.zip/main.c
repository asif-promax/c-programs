#include <stdio.h>
int value(int a){
    int sum=0;
    for(int i=1;i<=a;i++){
        sum=sum+i;
    }
    return sum;
}
int main()
{
    int n,sum;
    printf("enter a number :");
    scanf("%d",&n);
    // sum=value(n);
    printf("%d",value(n));
    return 0;
}
